<?php
    $koneksi = new mysqli("localhost", "root", " ", "dbpetshop");
?>